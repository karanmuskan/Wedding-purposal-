
import React from "react";
import ReactDOM from "react-dom/client";
import ProposalPage from "./ProposalPage";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <ProposalPage />
  </React.StrictMode>
);
